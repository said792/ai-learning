import { NextResponse } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import os from "os";
import crypto from "crypto";

import { suggestCategory } from "@/lib/ai/category-suggest";
import { analyzeDocument } from "@/lib/ai/analyzer";
import {
  extractTextFromAnyFile,
  isVideoExt,
  isAudioExt,
  isImageExt,
} from "@/lib/files/universal";
import { isSupportedExtension } from "@/lib/files/registry";
import {
  processDocumentAssets,
  getSignedAssetUrls,
} from "@/lib/files/document-images";
import { hashSessionToken } from "@/lib/auth";

/* =========================================================
   Supabase (العميل الموحد)
========================================================= */

import { supabaseAdmin as supabase } from "@/lib/supabaseAdmin";
import { ensureFreeSubscription, getEffectiveSubscription } from "@/lib/subscription";

export const runtime = "nodejs";

/* =========================================================
   Configuration
========================================================= */

const STORAGE_BUCKET = "documents";
const GUEST_DAILY_LIMIT = 3;
const USAGE_ACTION = "document_analysis";

const AUTH_COOKIE_NAMES = [
  "ai_learning_session",
  "auth_token",
  "session_token",
  "access_token",
  "token",
];

const GUEST_COOKIE_NAME = "ai_guest_id";
const GUEST_COOKIE_MAX_AGE = 60 * 60 * 24 * 365;

/* =========================================================
   Types
========================================================= */

type AuthUser = {
  id: string;
  full_name?: string | null;
  username?: string | null;
  phone?: string | null;
  national_id?: string | null;
  email?: string | null;
  role?: string | null;
  is_active?: boolean | null;
};

type SubscriptionInfo = {
  id: string;
  user_id: string;
  plan_id: string;
  start_date: string;
  end_date: string;
  status: string;
  plan: {
    id: string;
    name: string;
    monthly_limit: number | null;
    daily_limit: number | null;
    price: number | null;
    duration_days: number | null;
    is_active: boolean;
    features: Record<string, unknown> | null;
  };
};

type RequestIdentity = {
  user: AuthUser | null;
  userId: string | null;
  guestId: string | null;
};

/* =========================================================
   Arabic Detection
========================================================= */

function containsArabic(text: string): boolean {
  return /[\u0600-\u06FF]/.test(text);
}

/* =========================================================
   Cookie Parser
========================================================= */

function parseCookies(cookieHeader: string): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;

  for (const part of cookieHeader.split(";")) {
    const separatorIndex = part.indexOf("=");
    if (separatorIndex === -1) continue;

    const key = part.slice(0, separatorIndex).trim();
    const value = part.slice(separatorIndex + 1).trim();
    if (!key) continue;

    try {
      result[key] = decodeURIComponent(value);
    } catch {
      result[key] = value;
    }
  }

  return result;
}

/* =========================================================
   Guest ID
======================================================== */

function getOrCreateGuestId(request: Request): { guestId: string; isNew: boolean } {
  const cookieHeader = request.headers.get("cookie") || "";
  const cookies = parseCookies(cookieHeader);
  const existingGuestId = cookies[GUEST_COOKIE_NAME]?.trim();

  if (existingGuestId) {
    return { guestId: existingGuestId, isNew: false };
  }

  return { guestId: crypto.randomUUID(), isNew: true };
}

/* =========================================================
   Get Auth Token
======================================================== */

function getAuthToken(request: Request): string | null {
  const authorization = request.headers.get("authorization");
  if (authorization && authorization.toLowerCase().startsWith("bearer ")) {
    const token = authorization.slice(7).trim();
    if (token) return token;
  }

  const cookieHeader = request.headers.get("cookie") || "";
  const cookies = parseCookies(cookieHeader);

  for (const cookieName of AUTH_COOKIE_NAMES) {
    const token = cookies[cookieName]?.trim();
    if (token) return token;
  }

  return null;
}

/* =========================================================
   Get Current User
======================================================== */

async function getCurrentUser(request: Request): Promise<AuthUser | null> {
  const token = getAuthToken(request);
  if (!token) return null;

  const tokenHash = hashSessionToken(token);

  const { data: session, error: sessionError } = await supabase
    .from("auth_sessions")
    .select(`id, user_id, token_hash, expires_at`)
    .eq("token_hash", tokenHash)
    .gt("expires_at", new Date().toISOString())
    .maybeSingle();

  if (sessionError || !session) return null;

  const { data: user, error: userError } = await supabase
    .from("users")
    .select(`id, full_name, username, phone, national_id, email, role, is_active`)
    .eq("id", session.user_id)
    .maybeSingle();

  if (userError || !user || user.is_active === false) return null;

  return user as AuthUser;
}

/* =========================================================
   Prepare Identity
======================================================== */

async function prepareIdentity(request: Request): Promise<{ identity: RequestIdentity; isNewGuest: boolean }> {
  const user = await getCurrentUser(request);
  if (user) {
    return {
      identity: { user, userId: user.id, guestId: null },
      isNewGuest: false,
    };
  }

  const { guestId, isNew } = getOrCreateGuestId(request);
  return {
    identity: { user: null, userId: null, guestId },
    isNewGuest: isNew,
  };
}

/* =========================================================
   Active Subscription
======================================================== */

async function getActiveSubscription(userId: string): Promise<SubscriptionInfo | null> {
  /* الاشتراك الفعّال: الباقة المدفوعة السارية أولًا، وإلا الخطة المجانية */
  const data = await getEffectiveSubscription(
    userId,
    `id, user_id, plan_id, start_date, end_date, status,
     plan:plans ( id, name, monthly_limit, daily_limit, price, duration_days, is_active, features )`
  );

  if (!data) return null;

  const rawPlan = Array.isArray(data.plan) ? data.plan[0] : data.plan;
  if (!rawPlan) return null;

  return {
    id: String(data.id),
    user_id: String(data.user_id),
    plan_id: String(data.plan_id),
    start_date: String(data.start_date),
    end_date: String(data.end_date),
    status: String(data.status),
    plan: {
      id: String(rawPlan.id),
      name: String(rawPlan.name ?? ""),
      monthly_limit: (rawPlan.monthly_limit as number | null) ?? null,
      daily_limit: (rawPlan.daily_limit as number | null) ?? null,
      price: Number(rawPlan.price ?? 0),
      duration_days: Number(rawPlan.duration_days ?? 30),
      is_active: rawPlan.is_active !== false,
      features: rawPlan.features ?? null,
    },
  };
}

/* =========================================================
   Daily Usage
======================================================== */

async function countDailyUsage(userId: string | null, guestId: string | null): Promise<number> {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  const startIso = start.toISOString();

  let query = supabase
    .from("usage")
    .select("id", { count: "exact", head: true })
    .eq("action", USAGE_ACTION)
    .gte("created_at", startIso);

  if (userId) {
    query = query.eq("user_id", userId);
  } else if (guestId) {
    query = query.eq("guest_id", guestId);
  } else {
    return 0;
  }

  const { count, error } = await query;
  if (error) {
    console.error("[Usage] Daily count error:", error);
    throw new Error("تعذر التحقق من عدد الاستخدامات اليومية");
  }

  return count ?? 0;
}

/* =========================================================
   Monthly Usage
======================================================== */

async function countMonthlyUsage(userId: string): Promise<number> {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const startIso = start.toISOString();

  const { count, error } = await supabase
    .from("usage")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .eq("action", USAGE_ACTION)
    .gte("created_at", startIso);

  if (error) {
    console.error("[Usage] Monthly count error:", error);
    throw new Error("تعذر التحقق من الاستخدام الشهري");
  }

  return count ?? 0;
}

/* =========================================================
   Check Usage Permission
======================================================== */

async function checkUsagePermission(identity: RequestIdentity): Promise<{
  allowed: boolean;
  userType: "guest" | "subscriber";
  usedToday: number;
  dailyLimit: number;
  usedThisMonth?: number;
  monthlyLimit?: number;
  subscription?: SubscriptionInfo | null;
  reason?: string;
}> {
  if (!identity.userId) {
    const usedToday = await countDailyUsage(null, identity.guestId);
    const allowed = usedToday < GUEST_DAILY_LIMIT;
    return {
      allowed,
      userType: "guest",
      usedToday,
      dailyLimit: GUEST_DAILY_LIMIT,
      reason: allowed ? undefined : "لقد وصلت إلى الحد اليومي للزائر (3 ملفات). سجل حساب مجاني مدى الحياة — بدون تفعيل — عشان ترفع أكتر.",
    };
  }

  let subscription = await getActiveSubscription(identity.userId);

  if (!subscription) {
    /* شفاء ذاتي: لو مفيش اشتراك ساري (نادر) — نتأكد إن الخطة المجانية مفعّلة له */
    try {
      await ensureFreeSubscription(identity.userId);
      const retry = await getActiveSubscription(identity.userId);
      if (retry) {
        subscription = retry;
      }
    } catch {
      /* تجاهل — هنرجع رسالة الاشتراك تحت */
    }

    if (!subscription) {
      return {
        allowed: false,
        userType: "subscriber",
        usedToday: await countDailyUsage(identity.userId, null),
        dailyLimit: 0,
        subscription: null,
        reason: "لا يوجد اشتراك فعال. يرجى تحديث الصفحة أو الاشتراك للاستمرار في استخدام خدمات التحليل.",
      };
    }
  }

  if (subscription.plan.is_active === false) {
    return {
      allowed: false,
      userType: "subscriber",
      usedToday: await countDailyUsage(identity.userId, null),
      dailyLimit: 0,
      subscription,
      reason: "الباقة الحالية غير مفعلة.",
    };
  }

  const dailyLimit = Number(subscription.plan.daily_limit ?? 0);
  const monthlyLimit = Number(subscription.plan.monthly_limit ?? 0);
  const usedToday = await countDailyUsage(identity.userId, null);

  if (dailyLimit > 0 && usedToday >= dailyLimit) {
    return {
      allowed: false,
      userType: "subscriber",
      usedToday,
      dailyLimit,
      subscription,
      reason: `لقد وصلت إلى أقصى عدد لرفع الملفات اليوم (${usedToday} من ${dailyLimit}) في باقة "${subscription.plan.name}". انتظر حتى الغد، أو اشترك في باقة أعلى من صفحة الاشتراكات.`,
    };
  }

  const usedThisMonth = await countMonthlyUsage(identity.userId);

  if (monthlyLimit > 0 && usedThisMonth >= monthlyLimit) {
    return {
      allowed: false,
      userType: "subscriber",
      usedToday,
      dailyLimit,
      usedThisMonth,
      monthlyLimit,
      subscription,
      reason: `لقد وصلت إلى أقصى عدد لرفع الملفات هذا الشهر (${usedThisMonth} من ${monthlyLimit}) في باقة "${subscription.plan.name}". اشترك في باقة أعلى لمزيد من الملفات.`,
    };
  }

  return {
    allowed: true,
    userType: "subscriber",
    usedToday,
    dailyLimit,
    usedThisMonth,
    monthlyLimit,
    subscription,
  };
}

/* =========================================================
   Record Usage
======================================================== */

async function recordUsage(identity: RequestIdentity): Promise<void> {
  const { error } = await supabase.from("usage").insert({
    user_id: identity.userId,
    guest_id: identity.guestId,
    action: USAGE_ACTION,
  });

  if (error) {
    console.error("[Usage] Insert error:", error);
    throw new Error("فشل تسجيل استخدام التحليل");
  }
}

/* =========================================================
   Response With Guest Cookie
======================================================== */

function responseWithGuestCookie(
  body: Record<string, unknown>,
  status: number,
  identity: RequestIdentity,
  isNewGuest: boolean
): NextResponse {
  const response = NextResponse.json(body, { status });

  if (!identity.userId && identity.guestId && isNewGuest) {
    response.cookies.set(GUEST_COOKIE_NAME, identity.guestId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: GUEST_COOKIE_MAX_AGE,
      path: "/",
    });
  }

  return response;
}

/* =====================================================
   (مخططات MIME للصور انتقلت إلى lib/files/registry.ts)
===================================================== */

/* =========================================================
   POST
========================================================= */

export async function POST(request: Request) {
  let documentId: string | null = null;
  let identity: RequestIdentity | null = null;
  let isNewGuest = false;

  try {
    /* =====================================================
       Identity
    ===================================================== */
    const prepared = await prepareIdentity(request);
    identity = prepared.identity;
    isNewGuest = prepared.isNewGuest;

    console.log(
      "[Documents] Identity:",
      identity.userId ? `user:${identity.userId}` : `guest:${identity.guestId}`
    );

    /* =====================================================
       Read FormData
    ===================================================== */
    const formData = await request.formData();
    const file = formData.get("file");
    const lang = formData.get("lang") === "en" ? "en" : "ar";
    const categoryId = (formData.get("categoryId") as string | null) || null;

    if (!(file instanceof File)) {
      return responseWithGuestCookie(
        { success: false, error: "لم يتم إرسال ملف" },
        400,
        identity,
        isNewGuest
      );
    }

    /* =====================================================
       File Information
    ===================================================== */
    const originalFileName = file.name;
    const lowerFileName = originalFileName.toLowerCase();
    const extension = path.extname(lowerFileName);

    if (!extension || !isSupportedExtension(extension)) {
      return responseWithGuestCookie(
        {
          success: false,
          error: "نوع الملف غير مدعوم حاليًا — تحقق من قائمة الصيغ المدعومة في القائمة الجانبية",
          fileName: originalFileName,
          fileType: file.type,
        },
        400,
        identity,
        isNewGuest
      );
    }

    /* =====================================================
       Read File & Hash
    ===================================================== */
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const fileHash = crypto.createHash("sha256").update(buffer).digest("hex");

    const safeFileName = path.basename(originalFileName);
    const storageFileName = `${crypto.randomUUID()}${extension}`;
    const storagePath = `${fileHash}/${storageFileName}`;

    /* =====================================================
       Check Existing Document
    ===================================================== */
    let existingQuery = supabase
      .from("documents")
      .select(`
        id, file_name, file_hash, file_path, file_type, media_type, file_size,
        extracted_text, analysis, status, error_message, user_id, guest_id, created_at, updated_at
      `)
      .eq("file_hash", fileHash);

    if (identity.userId) {
      existingQuery = existingQuery.eq("user_id", identity.userId);
    } else if (identity.guestId) {
      existingQuery = existingQuery.eq("guest_id", identity.guestId).is("user_id", null);
    } else {
      existingQuery = existingQuery.eq("id", "00000000-0000-0000-0000-000000000000");
    }

    const { data: existingDocument, error: existingDocumentError } = await existingQuery.maybeSingle();

    if (existingDocumentError) {
      console.error("[Documents] Existing document lookup error:", existingDocumentError);
      throw new Error("تعذر البحث عن الملف في قاعدة البيانات");
    }

    /* =====================================================
       Existing Completed Document
    ===================================================== */
    if (existingDocument && existingDocument.status === "completed") {
      const analysisSummary = existingDocument.analysis?.summary || "";
      const isSavedInArabic = containsArabic(analysisSummary);

      if (lang === "en" && isSavedInArabic) {
        console.log(`[Documents] إعادة تحليل الملف باللغة الإنجليزية: ${originalFileName}`);
        const newAnalysis = await analyzeDocument(existingDocument.extracted_text || "", "en");

        const { error: updateError } = await supabase
          .from("documents")
          .update({ analysis: newAnalysis, updated_at: new Date().toISOString() })
          .eq("id", existingDocument.id);

        if (updateError) throw new Error(`فشل حفظ التحليل الجديد: ${updateError.message}`);

        return responseWithGuestCookie(
          {
            success: true,
            existing: true,
            documentId: existingDocument.id,
            fileName: existingDocument.file_name,
            mediaType: existingDocument.media_type,
            textLength: existingDocument.extracted_text?.length ?? 0,
            text: existingDocument.extracted_text?.substring(0, 1000) ?? "",
            analysis: newAnalysis,
            usageCharged: false,
            message: "لديك هذا الملف بالفعل، ولكن تم تحليله بالعربية. تم إعادة تحليله بالإنجليزية بنجاح.",
          },
          200,
          identity,
          isNewGuest
        );
      }

      if (lang === "ar" && !isSavedInArabic && analysisSummary.length > 20) {
        console.log(`[Documents] إعادة تحليل الملف باللغة العربية: ${originalFileName}`);
        const newAnalysis = await analyzeDocument(existingDocument.extracted_text || "", "ar");

        const { error: updateError } = await supabase
          .from("documents")
          .update({ analysis: newAnalysis, updated_at: new Date().toISOString() })
          .eq("id", existingDocument.id);

        if (updateError) throw new Error(`فشل حفظ التحليل الجديد: ${updateError.message}`);

        return responseWithGuestCookie(
          {
            success: true,
            existing: true,
            documentId: existingDocument.id,
            fileName: existingDocument.file_name,
            mediaType: existingDocument.media_type,
            textLength: existingDocument.extracted_text?.length ?? 0,
            text: existingDocument.extracted_text?.substring(0, 1000) ?? "",
            analysis: newAnalysis,
            usageCharged: false,
            message: "لديك هذا الملف بالفعل، ولكن تم تحليله بالإنجليزية. تم إعادة تحليله بالعربية بنجاح.",
          },
          200,
          identity,
          isNewGuest
        );
      }

      console.log(`[Documents] الملف موجود بالفعل لنفس المستخدم بنفس اللغة: ${originalFileName}`);
      return responseWithGuestCookie(
        {
          success: true,
          existing: true,
          documentId: existingDocument.id,
          fileName: existingDocument.file_name,
          mediaType: existingDocument.media_type,
          textLength: existingDocument.extracted_text?.length ?? 0,
          text: existingDocument.extracted_text?.substring(0, 1000) ?? "",
          analysis: existingDocument.analysis,
          usageCharged: false,
          message: "لديك بالفعل ملف بنفس المحتوى تم تحليله مسبقًا. تم استرجاع التحليل المحفوظ.",
        },
        200,
        identity,
        isNewGuest
      );
    }

    /* =====================================================
       Existing Processing
    ===================================================== */
    if (existingDocument && existingDocument.status === "processing") {
      return responseWithGuestCookie(
        {
          success: true,
          existing: true,
          processing: true,
          documentId: existingDocument.id,
          fileName: existingDocument.file_name,
          message: "الملف موجود بالفعل وما زال قيد المعالجة، يرجى الانتظار قليلاً.",
        },
        200,
        identity,
        isNewGuest
      );
    }

    /* =====================================================
       Existing Uploaded Video
    ===================================================== */
    if (existingDocument && existingDocument.status === "uploaded") {
      return responseWithGuestCookie(
        {
          success: true,
          existing: true,
          documentId: existingDocument.id,
          fileName: existingDocument.file_name,
          mediaType: existingDocument.media_type,
          usageCharged: false,
          message: "الملف موجود بالفعل وتم رفعه مسبقًا.",
        },
        200,
        identity,
        isNewGuest
      );
    }

    /* =====================================================
       Failed Document
    ===================================================== */
    if (existingDocument && existingDocument.status === "failed") {
      console.log(`[Documents] حذف السجل الفاشل وإعادة المحاولة: ${fileHash}`);
      const { error: deleteError } = await supabase
        .from("documents")
        .delete()
        .eq("id", existingDocument.id);

      if (deleteError) throw new Error("تعذر حذف السجل السابق للملف");
    }

    /* =====================================================
       Check Usage Limit
    ===================================================== */
    const usage = await checkUsagePermission(identity);

    console.log("[Usage]", {
      userType: usage.userType,
      usedToday: usage.usedToday,
      dailyLimit: usage.dailyLimit,
      usedThisMonth: usage.usedThisMonth,
      monthlyLimit: usage.monthlyLimit,
      allowed: usage.allowed,
    });

    if (!usage.allowed) {
      return responseWithGuestCookie(
        {
          success: false,
          limitReached: true,
          subscriptionExpired: Boolean(identity.userId && !usage.subscription),
          userType: usage.userType,
          usedToday: usage.usedToday,
          dailyLimit: usage.dailyLimit,
          usedThisMonth: usage.usedThisMonth ?? null,
          monthlyLimit: usage.monthlyLimit ?? null,
          plan: usage.subscription?.plan?.name ?? null,
          error: usage.reason || "تم الوصول إلى حد الاستخدام.",
        },
        403,
        identity,
        isNewGuest
      );
    }

    /* =====================================================
       Local Upload Directory
    ===================================================== */
    // Vercel: استخدم مجلد /tmp القابل للكتابة بدل مجلد المشروع
    const uploadDir = path.join(os.tmpdir(), "ai-learning-uploads");
    await mkdir(uploadDir, { recursive: true });

    const localFileName = `${crypto.randomUUID()}-${safeFileName}`;
    const filePath = path.join(uploadDir, localFileName);

    await writeFile(filePath, buffer);

    /* =====================================================
       Media Type Detection (موحد عبر registry)
    ===================================================== */
    const isVideo = isVideoExt(extension);
    const isAudio = isAudioExt(extension);
    const isImage = isImageExt(extension);
    const isMedia = isVideo || isAudio;

    const mediaType = isMedia ? "media" : "document";

    /* =====================================================
       Supabase Storage
    ===================================================== */
    console.log(`[Documents] رفع الملف إلى Supabase Storage: ${storagePath}`);

    const { error: storageError } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(storagePath, buffer, {
        contentType: file.type || "application/octet-stream",
        cacheControl: "3600",
        upsert: false,
      });

    if (storageError && !storageError.message.toLowerCase().includes("already exists")) {
      throw new Error(`فشل رفع الملف إلى Supabase Storage: ${storageError.message}`);
    }

    /* =====================================================
       استخراج النص عبر المُوجّه الموحد (كل الصيغ)
    ===================================================== */
    let text = "";
    let emptyReason: string | undefined;

    {
      const result = await extractTextFromAnyFile({
        filePath,
        originalName: originalFileName,
        extension,
        fileBuffer: buffer,
        fileMime: file.type || undefined,
        lang,
        isVideo,
        isAudio,
        isImage,
      });

      text = result.text;
      emptyReason = result.emptyReason;
    }

    if (!text.trim()) {
      return responseWithGuestCookie(
        {
          success: false,
          error:
            emptyReason ||
            "لم يتم استخراج أي نص من الملف حتى بعد محاولة قراءته بالذكاء الاصطناعي. تأكد من أن الملف يحتوي على نص واضح قابل للقراءة.",
          fileName: originalFileName,
        },
        422,
        identity,
        isNewGuest
      );
    }

    /* =====================================================
       Insert Processing Document
    ===================================================== */
    const { data: insertedDocument, error: insertDocumentError } = await supabase
      .from("documents")
      .insert({
        file_name: originalFileName,
        file_hash: fileHash,
        file_path: storagePath,
        file_type: file.type || extension,
        media_type: mediaType,
        file_size: buffer.length,
        extracted_text: text,
        analysis: null,
        status: "processing",
        error_message: null,
        user_id: identity.userId,
        guest_id: identity.guestId,
        category_id: categoryId,
      })
      .select()
      .single();

    if (insertDocumentError) {
      throw new Error(`فشل حفظ المستند في قاعدة البيانات: ${insertDocumentError.message}`);
    }

    documentId = insertedDocument.id;

    /* =====================================================
       Record Usage
    ===================================================== */
    await recordUsage(identity);
    console.log(`[Usage] تم تسجيل محاولة التحليل للمستخدم: ${identity.userId || identity.guestId}`);

    /* =====================================================
       AI Analysis
    ===================================================== */
    console.log(`[Documents] بدء تحليل Gemini باللغة: ${lang}...`);
    const analysis = await analyzeDocument(text, lang);

    /* =====================================================
       Save Analysis
    ===================================================== */
    const { error: updateDocumentError } = await supabase
      .from("documents")
      .update({
        analysis,
        status: "completed",
        error_message: null,
        updated_at: new Date().toISOString(),
      })
      .eq("id", documentId);

    if (updateDocumentError) {
      throw new Error(`تم التحليل ولكن فشل حفظ التحليل: ${updateDocumentError.message}`);
    }

    console.log(`[Documents] تم حفظ التحليل بنجاح: ${documentId}`);

    /* =====================================================
       AI Category Suggestion
    ===================================================== */
    let categorySuggestion: { suggestedName: string | null; confidence: string } = {
      suggestedName: null,
      confidence: "low",
    };

    if (!categoryId && text.trim()) {
      try {
        let catNameQuery = supabase
          .from("categories")
          .select("name");

        if (identity.userId) {
          catNameQuery = catNameQuery.eq("user_id", identity.userId);
        } else if (identity.guestId) {
          catNameQuery = catNameQuery.eq("guest_id", identity.guestId).is("user_id", null);
        }

        const { data: existingCats } = await catNameQuery;
        const catNames = (existingCats || []).map((c: { name: string }) => c.name);

        const analysisSummary = analysis?.summary || analysis?.title || "";
        const suggestionInput = `${analysisSummary}\n\n${text.substring(0, 1000)}`;

        categorySuggestion = await suggestCategory(suggestionInput, catNames, lang);
      } catch (e) {
        console.error("[Documents] Category suggestion error:", e);
      }
    }

    /* =====================================================
       صور المستند: استخراج + تحليل + رفع (غير حرج)
    ===================================================== */
    let assets: Array<{
      id: string;
      url: string | null;
      pageNumber: number | null;
      source: string;
      analysis: {
        description: string;
        textInImage?: string;
        educationalNote?: string;
      } | null;
    }> = [];

    try {
      const storedAssets = await processDocumentAssets({
        documentId: documentId as string,
        filePath,
        extension,
        documentTitle: analysis?.title || originalFileName,
        userId: identity.userId ?? null,
        guestId: identity.guestId ?? null,
        lang,
      });

      if (storedAssets.length > 0) {
        const signedUrls = await getSignedAssetUrls(
          storedAssets.map((a) => a.storage_path)
        );

        assets = storedAssets.map((a) => ({
          id: a.id,
          url: signedUrls[a.storage_path] || null,
          pageNumber: a.page_number,
          source: a.source,
          analysis: a.analysis,
        }));
      }
    } catch (assetsError) {
      console.error("[Documents] خطأ في خط الصور (غير حرج):", assetsError);
    }

    /* =====================================================
       Final Usage
    ===================================================== */
    const finalUsage = await checkUsagePermission(identity);

    /* =====================================================
       Success
    ===================================================== */
    return responseWithGuestCookie(
      {
        success: true,
        existing: false,
        documentId,
        fileName: originalFileName,
        mediaType,
        textLength: text.length,
        text: text.substring(0, 1000),
        analysis,
        categorySuggestion,
        assets,
        usage: {
          userType: finalUsage.userType,
          usedToday: finalUsage.usedToday,
          dailyLimit: finalUsage.dailyLimit,
          usedThisMonth: finalUsage.usedThisMonth ?? null,
          monthlyLimit: finalUsage.monthlyLimit ?? null,
          plan: finalUsage.subscription?.plan?.name ?? null,
        },
        usageCharged: true,
        message: isMedia
          ? "تم رفع الملف الصوتي/الفيديو واستخراج النص وتحليله بنجاح."
          : isImage
          ? "تم رفع الصورة واستخراج النص بالذكاء الاصطناعي وتحليله بنجاح."
          : "تم رفع الملف وتحليله وحفظه بنجاح.",
      },
      200,
      identity,
      isNewGuest
    );
  } catch (error) {
    console.error("[Documents] File processing error:", error);

    /* =====================================================
       Mark Document Failed
    ===================================================== */
    if (documentId) {
      try {
        await supabase
          .from("documents")
          .update({
            status: "failed",
            error_message: error instanceof Error ? error.message : "حدث خطأ غير معروف",
            updated_at: new Date().toISOString(),
          })
          .eq("id", documentId);
      } catch (databaseError) {
        console.error("[Documents] Failed to update document status:", databaseError);
      }
    }

    const message = error instanceof Error ? error.message : "حدث خطأ غير معروف";
    const lowerMessage = message.toLowerCase();

    const isGeminiQuota =
      lowerMessage.includes("quota") ||
      lowerMessage.includes("429") ||
      lowerMessage.includes("rate limit") ||
      lowerMessage.includes("resource exhausted");

    return responseWithGuestCookie(
      {
        success: false,
        error: isGeminiQuota
          ? "خدمة الذكاء الاصطناعي وصلت إلى الحد المتاح حاليًا. حاول مرة أخرى لاحقًا."
          : "حدث خطأ أثناء معالجة الملف، يرجى المحاولة مرة أخرى.",
        details: message,
        geminiQuota: isGeminiQuota,
        documentId: documentId,
      },
      500,
      identity || { user: null, userId: null, guestId: null },
      isNewGuest
    );
  }
}